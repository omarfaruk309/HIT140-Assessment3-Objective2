# Facts for the AI Usage Declaration Form

This file lists what the AI tool did in this project, so the team can complete the form accurately.
**The reflection in the form must be written by the team in your own words.** Do not paste this file into the form as it is.

## Tool

Claude (Anthropic), used through the Claude desktop app (Cowork), 25 September to 2 October 2026.
Conversation URL: paste the share link of this conversation. In the Claude app, use **Share** on the conversation to create it.

## Which declaration fits

The code and datasets generated with AI are included in the submission, so **Declaration 3** ("materials that are included in our work in modified forms") is the closest match. Before ticking it, review and modify the code yourselves (for example, rename variables, adjust comments, rerun it). If you submit the code unmodified, say so honestly in Table 2.

## What the AI tool did

1. Read the assessment instructions and the project brief supplied by the team.
2. Located FIFA's public data feeds behind the fifa.com statistics page, and downloaded the match list, the 142 team statistics per match, the FIFA ranking and past World Cup matches through the browser on the team member's computer.
3. Proposed the candidate variables, the rule that tournament statistics are only used from earlier matches (the leakage test), and the data driven selection procedure that chooses the 8 variables.
4. Wrote the Python code in four notebooks (data collection, data wrangling, Regression 2.1, Regression 2.2), including comments, and executed them. This includes alternative models, the optimisation steps (reliability weighting, Yeo-Johnson transformation, Ridge), nested cross validation, the comparison of competing algorithms and the storytelling figures.
5. Cross checked the data: an independent source (martj42/international_results on GitHub) has identical scores for all 104 matches.
6. Revised the work after the team shared the Assessment 2 rubric feedback, the Assessment 3 rubric and the lecturer's Objective 2 Q&A answers.
7. Produced a report outline with the verified results and a list of real references. **It did not write the report text.**

## What the team must do and be able to explain

* Write the report in your own words, as the brief requires.
* Understand every block of code. The brief says you must be able to explain all of it.
* Decide who owns each part, and record the discussion on Microsoft Teams.
* Run Turnitin on the final report.
