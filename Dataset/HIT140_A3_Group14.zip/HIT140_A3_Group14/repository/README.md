# FIFA World Cup 2026: Objective 2 (HIT140 Assessment 3, Sydney Group 14)

Two multiple linear regression models built from FIFA's official data. Every explanatory variable uses only information available **before** kickoff.

| Model | Target | Rows | Final dataset |
|---|---|---|---|
| Linear Regression 2.1 | goal difference between two teams | 104 matches | `data/processed/wc2026_goal_difference.csv` |
| Linear Regression 2.2 | goals scored by one team | 208 team matches | `data/processed/wc2026_team_goals.csv` |

Each final dataset contains ID fields, the target and **exactly 8 explanatory variables**. At most 4 underlying statistics are shared between the two models.

## Four parts, run in order (1 → 2 → 3 → 4)

| Part | Notebook | What it does |
|---|---|---|
| 1 | [part1_data_collection.ipynb](Part_1_Data_Collection/part1_data_collection.ipynb) | Downloads the data from FIFA's data feeds; runs completeness checks; cross checks every score against an independent source |
| 2 | [part2_data_wrangling.ipynb](Part_2_Data_Wrangling/part2_data_wrangling.ipynb) | Cleans the data; engineers 23 (Model 2.1) and 37 (Model 2.2) pre match candidate variables; leakage test |
| 3 | [part3_regression_2_1.ipynb](Part_3_Regression_2_1/part3_regression_2_1.ipynb) | Model 2.1: systematic variable selection (EDA, relevance, redundancy, VIF), evaluation, inference, assumptions, alternative models, step by step optimisation (reliability weighting, Yeo-Johnson, Ridge), nested cross validation, competing algorithms, recommendation and storytelling figures |
| 4 | [part4_regression_2_2.ipynb](Part_4_Regression_2_2/part4_regression_2_2.ipynb) | Model 2.2: the same workflow with match grouped splits, the shared variable limit, cluster robust errors and count model alternatives |

Each notebook is made of numbered, commented blocks. All notebooks are already executed, so their outputs appear under each cell. Each part also saves its outputs to its own `tables/` and `figures/` folders.

## Data sources (accessed September 2026)

* **FIFA statistics page:** https://www.fifa.com/en/tournaments/mens/worldcup/canadamexicousa2026/statistics
* **FIFA data feeds used by that page:**
  * matches: `https://api.fifa.com/api/v3/calendar/matches?idCompetition=17&idSeason=285023&count=200&language=en`
  * 142 team statistics per match: `https://fdh-api.fifa.com/v1/stats/match/{IdIFES}/teams.json`
  * ranking: `https://api.fifa.com/api/v3/rankings?gender=1&count=300&language=en`
  * past World Cups: `https://api.fifa.com/api/v3/seasons?idCompetition=17&count=50&language=en`
* **Independent cross check:** martj42/international_results, https://github.com/martj42/international_results. Its World Cup 2026 rows are saved in `data/external/`.

Folders: `data/raw/` (FIFA files), `data/external/` (cross check), `data/processed/` (candidate tables and final datasets).

**Part 1 downloads live data.** It runs offline by default (`DOWNLOAD = False`) and uses the saved raw files. FIFA may publish a newer ranking later; the saved file keeps the pre tournament values from 11 June 2026.

## Setup

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Open each notebook in VS Code or Jupyter, select the `.venv` kernel, and click **Run All**, in the order Part 1 to Part 4. Part 4 reads Model 2.1's final variables to apply the shared variable limit.

## Key methodological decisions

* **Leakage:** in match statistics are used only as averages of a team's **earlier** matches, centred on the tournament average so far (0 in a team's first match). Part 2, Block 8 tests this.
* **Selection on training data only:** the 80/20 split happens before variables are chosen, so the test set never influences a decision.
* **Selection rule:**
  1. Rank candidates by |r| with the target.
  2. Skip near duplicates (|r| ≥ 0.8).
  3. Keep VIF below 5.
  4. Allow at most 4 underlying statistics shared with Model 2.1.
* **Honest evaluation:** nested cross validation reruns the whole selection inside every training fold.
* **Model comparison:** 8 scikit-learn algorithms on identical folds, compared with the corrected resampled t test (Nadeau and Bengio, 2003).
