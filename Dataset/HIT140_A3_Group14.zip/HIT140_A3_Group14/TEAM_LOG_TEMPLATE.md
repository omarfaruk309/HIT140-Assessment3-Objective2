# Team Log: HIT140 Assessment 3, Sydney Group 14

Fill this in as you work, and keep the matching discussion on **Microsoft Teams**: only Teams counts as collaboration evidence.
Record real events only. Copy the decisions into your Teams channel so the record exists there too.

## Ownership

| Part | Owner | Reviewer | Status |
|---|---|---|---|
| Part 1: data acquisition and validation | | | |
| Part 2: candidate variables and wrangling | | | |
| Part 3: Linear Regression 2.1 | | | |
| Part 4: Linear Regression 2.2 | | | |
| Introduction and conclusion | | | |
| Final proofread and submission | | | |

## Decision log

| Date | Decision | Reason | Agreed by |
|---|---|---|---|
| | e.g. use FIFA's official data feeds as the data source | | |
| | e.g. apply the stricter shared variable rule (same statistic = shared) | | |
| | e.g. recommend linear regression over competing algorithms | | |

## Progress checks and reviews

| Date | Who | What was checked or reviewed | Outcome |
|---|---|---|---|
| | | | |

## Individual contributions (fill in at the end)

| Member | Main contributions |
|---|---|
| Lamim Hasan (S394752) | |
| Mir Saifur Rahman (S398452) | |
| Omar Faruk (S397782) | |
| Sraboni Sutradhar (S401805) | |
